// Base class for items

public abstract class MenuItem {
	
    private String name;
    private double price;
    private int calories;
    private String description;

    public MenuItem(String name, double price, int calories, String description) {
    	
        this.name = name;
        this.price = price;
        this.calories = calories;
        this.description = description;
        
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getCalories() { return calories; }
    public String getDescription() { return description; }

    // Drink / Meal / Snack
    
    public abstract String getCategory();

    // Text shown in the list
    
    public String displayInfo() {
    	
        return getCategory() + " - " + name + " | $" + String.format("%.2f", price) + " | " + calories + " cal | " + description;
        
    }
}
