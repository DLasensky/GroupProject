// Meal

public class Meal extends MenuItem {
	
    private String type;

    public Meal(String name, double price, int calories, String description, String type) {
    	
        super(name, price, calories, description);
        this.type = type;
        
    }

    public String getCategory() { return "Meal"; }

    public String displayInfo() {
    	
        return super.displayInfo() + " | Type: " + type;
        
    }
}
