// Snack

public class Snack extends MenuItem {
	
    private String brand;

    public Snack(String name, double price, int calories, String description, String brand) {
    	
        super(name, price, calories, description);
        this.brand = brand;
        
    }

    public String getCategory() { return "Snack"; }

    public String displayInfo() {
    	
        return super.displayInfo() + " | Brand: " + brand;
        
    }
}
