// Drink

public class Drink extends MenuItem {
	
    private String size;

    public Drink(String name, double price, int calories, String description, String size) {
    	
        super(name, price, calories, description);
        this.size = size;
        
    }

    public String getCategory() { return "Drink"; }

    public String displayInfo() {
    	
        return super.displayInfo() + " | Size: " + size;
        
    }
}
